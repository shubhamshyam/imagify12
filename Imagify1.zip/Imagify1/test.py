import time
import hmac
import hashlib
import requests
import json
import math

# ─────────────────────────────────────────────
#  CONFIGURATION
# ─────────────────────────────────────────────
API_KEY    = "hv6gP6Y8151hHzsZ2VaE7RuMVKUW5F"
API_SECRET = "fdAokFlw6bCNf7rP6M1BSLheltppV8EEp9bTiJiM4jsOYE7Ap0kGOir60b60"

BASE_URL   = "https://cdn-ind.testnet.deltaex.org"

BTCUSD_PRODUCT_ID = 27       # BTCUSD Perpetual Futures
CONTRACT_SIZE_BTC = 0.001    # 1 contract = 0.001 BTC on Delta Exchange
TRADE_AMOUNT_USD  = 50       # How much USD to trade
SELL_AFTER_SEC    = 5        # Sell after N seconds


# ─────────────────────────────────────────────
#  CORE: Signature + Request
# ─────────────────────────────────────────────
def signed_request(method, path, query_string="", payload=None):
    body = json.dumps(payload, separators=(',', ':')) if payload else ""
    timestamp = str(int(time.time()))
    msg = method + timestamp + path + query_string + body
    signature = hmac.new(
        API_SECRET.encode("utf-8"),
        msg.encode("utf-8"),
        hashlib.sha256
    ).hexdigest()
    headers = {
        "api-key":      API_KEY,
        "timestamp":    timestamp,
        "signature":    signature,
        "Content-Type": "application/json",
        "User-Agent":   "python-delta-local/1.0"
    }
    url = BASE_URL + path + query_string
    if method == "GET":
        r = requests.get(url, headers=headers, timeout=10)
    elif method == "POST":
        r = requests.post(url, headers=headers, data=body, timeout=10)
    elif method == "DELETE":
        r = requests.delete(url, headers=headers, data=body, timeout=10)
    else:
        return None

    if not r.text.strip():
        print(f"  ERROR: Empty response (status {r.status_code})")
        return None

    data = r.json()
    if r.status_code != 200 or not data.get("success", True):
        print(f"  API ERROR: {json.dumps(data.get('error', data), indent=2)}")
    return data


# ─────────────────────────────────────────────
#  STEP 1: Get BTC Mark Price + Orderbook Prices
# ─────────────────────────────────────────────
def get_btc_ticker():
    print("\n[1] Fetching BTC ticker...")
    r = requests.get(f"{BASE_URL}/v2/tickers/BTCUSD", timeout=10)
    if r.status_code == 200 and r.text.strip():
        result = r.json().get("result", {})
        mark_price = float(result.get("mark_price", 0))
        best_bid   = result.get("quotes", {}).get("best_bid", None)
        best_ask   = result.get("quotes", {}).get("best_ask", None)
        print(f"  Mark Price : ${mark_price:,.2f}")
        print(f"  Best Bid   : {best_bid}")
        print(f"  Best Ask   : {best_ask}")
        return mark_price, best_bid, best_ask
    print(f"  ERROR {r.status_code}: {r.text}")
    return None, None, None


# ─────────────────────────────────────────────
#  STEP 2: Calculate Contract Size for $50 USD
#  Formula: size = floor(USD_amount / (mark_price * CONTRACT_SIZE_BTC))
#  Minimum size = 1 contract
# ─────────────────────────────────────────────
def calculate_size(mark_price, usd_amount):
    value_per_contract = mark_price * CONTRACT_SIZE_BTC  # USD value of 1 contract
    size = max(1, math.floor(usd_amount / value_per_contract))
    actual_usd = size * value_per_contract
    print(f"\n[2] Contract Size Calculation")
    print(f"  BTC Mark Price       : ${mark_price:,.2f}")
    print(f"  Value per Contract   : ${value_per_contract:,.4f}  (0.001 BTC)")
    print(f"  Target Amount        : ${usd_amount}")
    print(f"  Contracts to Buy     : {size}")
    print(f"  Actual Trade Value   : ${actual_usd:,.4f}")
    return size


# ─────────────────────────────────────────────
#  STEP 3: Place BUY Limit Order
# ─────────────────────────────────────────────
def place_buy_order(mark_price, size):
    # Use mark_price directly — close to market, will fill quickly
    limit_price = round(mark_price * 1.005, 1)  # 0.5% above mark = fast fill
    print(f"\n[3] Placing BUY Limit Order...")
    print(f"  Size        : {size} contracts (~${size * mark_price * CONTRACT_SIZE_BTC:,.2f} USD)")
    print(f"  Limit Price : ${limit_price:,.1f}")

    payload = {
        "product_id":     BTCUSD_PRODUCT_ID,
        "product_symbol": "BTCUSD",
        "size":           size,
        "side":           "buy",
        "order_type":     "limit_order",
        "limit_price":    str(limit_price),
        "time_in_force":  "gtc",
        "post_only":      False,
        "reduce_only":    False
    }

    data = signed_request("POST", "/v2/orders", payload=payload)
    if data and data.get("success"):
        order = data.get("result", {})
        order_id = order.get("id")
        print(f"  ✅ BUY Order Placed!")
        print(f"  Order ID    : {order_id}")
        print(f"  Status      : {order.get('state')}")
        print(f"  Limit Price : {order.get('limit_price')}")
        return order_id, float(limit_price)
    return None, None


# ─────────────────────────────────────────────
#  STEP 4: Wait N seconds then SELL to close
# ─────────────────────────────────────────────
def place_sell_order(mark_price, size):
    # Sell slightly below mark price for fast fill
    limit_price = round(mark_price * 0.995, 1)  # 0.5% below mark = fast fill
    print(f"\n[5] Placing SELL Limit Order (close position)...")
    print(f"  Size        : {size} contracts")
    print(f"  Limit Price : ${limit_price:,.1f}")

    payload = {
        "product_id":     BTCUSD_PRODUCT_ID,
        "product_symbol": "BTCUSD",
        "size":           size,
        "side":           "sell",
        "order_type":     "limit_order",
        "limit_price":    str(limit_price),
        "time_in_force":  "gtc",
        "post_only":      False,
        "reduce_only":    True   # closes existing position only
    }

    data = signed_request("POST", "/v2/orders", payload=payload)
    if data and data.get("success"):
        order = data.get("result", {})
        print(f"  ✅ SELL Order Placed!")
        print(f"  Order ID    : {order.get('id')}")
        print(f"  Status      : {order.get('state')}")
        print(f"  Limit Price : {order.get('limit_price')}")
        return order.get("id")
    return None


# ─────────────────────────────────────────────
#  STEP 5: Check Position
# ─────────────────────────────────────────────
def get_position():
    print(f"\n[INFO] Current BTC Position:")
    data = signed_request("GET", "/v2/positions",
                          query_string=f"?product_id={BTCUSD_PRODUCT_ID}")
    if data:
        result = data.get("result", {})
        if result and result.get("size", 0) != 0:
            entry  = result.get("entry_price", "N/A")
            size   = result.get("size", 0)
            pnl    = result.get("unrealized_pnl", "N/A")
            mark   = result.get("mark_price", "N/A")
            print(f"  Size          : {size} contracts")
            print(f"  Entry Price   : ${entry}")
            print(f"  Mark Price    : ${mark}")
            print(f"  Unrealized PnL: ${pnl}")
        else:
            print("  No open BTC position.")
    return data


# ─────────────────────────────────────────────
#  STEP 6: Get current wallet balance
# ─────────────────────────────────────────────
def get_usd_balance():
    data = signed_request("GET", "/v2/wallet/balances")
    if data:
        for item in data.get("result", []):
            if item.get("asset_symbol") == "USD":
                print(f"\n  💰 USD Balance: ${item.get('available_balance')} available "
                      f"(total: ${item.get('balance')})")
                return float(item.get("available_balance", 0))
    return 0


# ─────────────────────────────────────────────
#  MAIN — Full Buy → Wait 5s → Sell Flow
# ─────────────────────────────────────────────
if __name__ == "__main__":

    print("=" * 55)
    print("   Delta Exchange BTC Trade Bot — $50 / 5s Auto Sell")
    print("=" * 55)

    # 1. Get balance
    print("\n[0] Checking USD Balance...")
    balance = get_usd_balance()
    if balance < TRADE_AMOUNT_USD:
        print(f"  ⚠️  Insufficient balance: ${balance} < ${TRADE_AMOUNT_USD}")
        exit()
    print(f"  ✅ Sufficient balance: ${balance}")

    # 2. Get BTC price
    mark_price, best_bid, best_ask = get_btc_ticker()
    if not mark_price:
        print("  ❌ Could not fetch BTC price. Exiting.")
        exit()

    # 3. Calculate how many contracts = $50
    size = calculate_size(mark_price, TRADE_AMOUNT_USD)

    # 4. Place BUY order
    buy_order_id, buy_price = place_buy_order(mark_price, size)
    if not buy_order_id:
        print("  ❌ BUY order failed. Exiting.")
        exit()

    # 5. Check position after buy
    get_position()

    # 6. ⏳ Wait 5 seconds
    print(f"\n[4] ⏳ Waiting {SELL_AFTER_SEC} seconds before selling...")
    for i in range(SELL_AFTER_SEC, 0, -1):
        print(f"  Selling in {i}s...", end="\r")
        time.sleep(1)
    print()

    # 7. Refresh mark price before selling
    mark_price, _, _ = get_btc_ticker()

    # 8. Place SELL order to close position
    sell_order_id = place_sell_order(mark_price, size)

    # 9. Final position + balance check
    time.sleep(2)  # wait for order to process
    get_position()
    print("\n[FINAL BALANCE]")
    get_usd_balance()

    print("\n" + "=" * 55)
    print("  Trade Cycle Complete ✅")
    print(f"  BUY  Order ID : {buy_order_id}")
    print(f"  SELL Order ID : {sell_order_id}")
    print("=" * 55)
